App.onJoinPlayer.Add(function(player){
	App.showCenterLabel("Hello world")
})
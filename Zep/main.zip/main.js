// let Spartan = App.loadSpritesheet('spartan.png', 64, 96, {
//     left: [0, 1, 2, 3],
//     up: [0],
//     down: [0],
//     right: [0, 1, 2, 3]
// }, 8);
// 르타인 캐릭터 넣기

App.onSay.Add(function(Player, text){
    
    if(text == 'speed up'){
        Player.moveSpeed = 400;
    }
    if(text == 'speed down'){
        Player.moveSpeed = 30;
    }

    App.showCenterLabel(message);

})
// App.onJoinPlayer.Add(function(Player){

//     // Player.Sprite = Spartan;
//     // Player.sendUpdated();
// })